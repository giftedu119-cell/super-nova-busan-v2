CREATE TABLE `reviews` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`name` text NOT NULL,
	`item` text NOT NULL,
	`market` text NOT NULL,
	`paid` integer NOT NULL,
	`rating` integer DEFAULT 5 NOT NULL,
	`review_text` text NOT NULL,
	`receipt_verified` integer DEFAULT false NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_reviews_created_at` ON `reviews` (`created_at`);
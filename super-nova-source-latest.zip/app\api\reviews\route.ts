import { desc } from "drizzle-orm";
import { getDb } from "../../../db";
import { reviews } from "../../../db/schema";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Cache-Control": "no-store",
};

function json(body: unknown, status = 200) {
  return Response.json(body, { status, headers: corsHeaders });
}

function errorMessage(error: unknown) {
  const message = error instanceof Error ? error.message : "Unexpected error";
  return message.includes("no such table")
    ? "후기 저장소를 준비하는 중입니다. 잠시 후 다시 시도해 주세요."
    : message;
}

export function OPTIONS() {
  return new Response(null, { status: 204, headers: corsHeaders });
}

export async function GET() {
  try {
    const rows = await getDb()
      .select()
      .from(reviews)
      .orderBy(desc(reviews.createdAt), desc(reviews.id))
      .limit(60);
    return json({ reviews: rows });
  } catch (error) {
    return json({ error: errorMessage(error) }, 500);
  }
}

export async function POST(request: Request) {
  try {
    const payload = (await request.json()) as {
      name?: string;
      item?: string;
      market?: string;
      paid?: number;
      rating?: number;
      reviewText?: string;
    };

    const name = payload.name?.trim() ?? "";
    const item = payload.item?.trim() ?? "";
    const market = payload.market?.trim() ?? "";
    const paid = Math.round(Number(payload.paid));
    const rating = Math.round(Number(payload.rating));
    const reviewText = payload.reviewText?.trim() ?? "";

    if (name.length < 2 || name.length > 30) return json({ error: "닉네임은 2~30자로 입력해 주세요." }, 400);
    if (!item || item.length > 60) return json({ error: "구매 품목을 확인해 주세요." }, 400);
    if (!market || market.length > 60) return json({ error: "구매 시장을 확인해 주세요." }, 400);
    if (!Number.isFinite(paid) || paid < 1 || paid > 100_000_000) return json({ error: "결제 금액을 확인해 주세요." }, 400);
    if (!Number.isInteger(rating) || rating < 0 || rating > 5) return json({ error: "별점은 0~5점으로 선택해 주세요." }, 400);
    if (reviewText.length < 5 || reviewText.length > 500) return json({ error: "후기는 5~500자로 입력해 주세요." }, 400);

    const [review] = await getDb().insert(reviews).values({
      name,
      item,
      market,
      paid,
      rating,
      reviewText,
      receiptVerified: false,
    }).returning();

    return json({ review }, 201);
  } catch (error) {
    return json({ error: errorMessage(error) }, 500);
  }
}

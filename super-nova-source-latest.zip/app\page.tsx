"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import {
  categoryLabels,
  freshnessLabels,
  languageOptions,
  marketLabels,
  messages,
  seafoodLabels,
  type Language,
} from "./translations";

type PriceLevel = "safe" | "caution" | "danger";
type PhoneMessageKey = "phoneIntro" | "invalidPhone" | "codeSent" | "verified" | "invalidCode" | "verifyFirst";

type Seafood = {
  name: string;
  unit: string;
  price: number;
  change: number;
  range: string;
  freshness: string;
  icon: string;
  photo?: string;
  tone: string;
};

type Transaction = {
  id: string;
  time: string;
  item: string;
  market: string;
  weight: string;
  total: string;
  fair: boolean;
};

type Review = {
  id: number | string;
  name: string;
  market: string;
  createdAt?: string;
  minutesAgo?: number;
  text: string;
  paid: number;
  item: string;
  color: string;
  rating: number;
  receiptVerified: boolean;
};

const seafood: Seafood[] = [
  { name: "광어", unit: "1kg", price: 28000, change: -3.2, range: "25,000–31,000", freshness: "활어", icon: "🐟", tone: "mint" },
  { name: "참돔", unit: "1kg", price: 35000, change: 1.8, range: "32,000–39,000", freshness: "활어", icon: "🐠", tone: "coral" },
  { name: "대게", unit: "1kg", price: 72000, change: -5.1, range: "68,000–79,000", freshness: "활어", icon: "🦀", tone: "blue" },
  { name: "전복", unit: "10미", price: 42000, change: 0.7, range: "38,000–46,000", freshness: "활패", icon: "🐚", tone: "sand" },
  { name: "문어", unit: "1kg", price: 31000, change: 2.4, range: "28,000–35,000", freshness: "선어", icon: "🐙", tone: "violet" },
  { name: "멍게", unit: "1kg", price: 15000, change: -1.4, range: "13,000–18,000", freshness: "활패", icon: "", photo: "https://upload.wikimedia.org/wikipedia/commons/thumb/1/19/SeaSquirt.jpg/330px-SeaSquirt.jpg", tone: "orange" },
];

const annualPriceHistory: Record<string, { month: string; price: number }[]> = {
  광어: [{ month: "9월", price: 31000 }, { month: "10월", price: 29500 }, { month: "11월", price: 32000 }, { month: "12월", price: 34500 }, { month: "1월", price: 33000 }, { month: "2월", price: 30500 }, { month: "3월", price: 29000 }, { month: "4월", price: 27500 }, { month: "5월", price: 28500 }, { month: "6월", price: 30000 }, { month: "7월", price: 29000 }, { month: "8월", price: 28000 }],
  참돔: [{ month: "9월", price: 32000 }, { month: "10월", price: 33500 }, { month: "11월", price: 34000 }, { month: "12월", price: 37500 }, { month: "1월", price: 39500 }, { month: "2월", price: 38000 }, { month: "3월", price: 36000 }, { month: "4월", price: 34000 }, { month: "5월", price: 33000 }, { month: "6월", price: 34500 }, { month: "7월", price: 35000 }, { month: "8월", price: 35000 }],
  대게: [{ month: "9월", price: 82000 }, { month: "10월", price: 88000 }, { month: "11월", price: 95000 }, { month: "12월", price: 110000 }, { month: "1월", price: 126000 }, { month: "2월", price: 118000 }, { month: "3월", price: 98000 }, { month: "4월", price: 83000 }, { month: "5월", price: 76000 }, { month: "6월", price: 73000 }, { month: "7월", price: 74000 }, { month: "8월", price: 72000 }],
  전복: [{ month: "9월", price: 39000 }, { month: "10월", price: 40000 }, { month: "11월", price: 43000 }, { month: "12월", price: 46000 }, { month: "1월", price: 48000 }, { month: "2월", price: 45500 }, { month: "3월", price: 44000 }, { month: "4월", price: 42000 }, { month: "5월", price: 40000 }, { month: "6월", price: 41000 }, { month: "7월", price: 43000 }, { month: "8월", price: 42000 }],
  문어: [{ month: "9월", price: 36000 }, { month: "10월", price: 35000 }, { month: "11월", price: 38000 }, { month: "12월", price: 42000 }, { month: "1월", price: 43000 }, { month: "2월", price: 39000 }, { month: "3월", price: 35000 }, { month: "4월", price: 32000 }, { month: "5월", price: 30000 }, { month: "6월", price: 29500 }, { month: "7월", price: 30500 }, { month: "8월", price: 31000 }],
  멍게: [{ month: "9월", price: 19000 }, { month: "10월", price: 17500 }, { month: "11월", price: 16000 }, { month: "12월", price: 15000 }, { month: "1월", price: 14500 }, { month: "2월", price: 14000 }, { month: "3월", price: 16000 }, { month: "4월", price: 18500 }, { month: "5월", price: 21000 }, { month: "6월", price: 19500 }, { month: "7월", price: 16500 }, { month: "8월", price: 15000 }],
};

const initialTransactions: Transaction[] = [
  { id: "seed-1", time: "14:31", item: "광어", market: "자갈치시장", weight: "1.8kg", total: "50,000원", fair: true },
  { id: "seed-2", time: "14:28", item: "대게", market: "민락회센터", weight: "2.1kg", total: "148,000원", fair: true },
  { id: "seed-3", time: "14:24", item: "전복", market: "부전시장", weight: "10미", total: "43,000원", fair: true },
  { id: "seed-4", time: "14:19", item: "참돔", market: "자갈치시장", weight: "1.5kg", total: "53,000원", fair: true },
];

const initialReviews: Review[] = [
  { id: "seed-review-1", name: "정민수", market: "자갈치시장", minutesAgo: 12, text: "광어 2kg에 5만 6천 원! 시세표 보여드리니 손질비까지 먼저 정확히 안내해주셨어요.", paid: 56000, item: "광어 2kg", color: "navy", rating: 5, receiptVerified: true },
  { id: "seed-review-2", name: "Emma L.", market: "민락회센터", minutesAgo: 38, text: "가격과 무게를 앱으로 바로 비교할 수 있어 안심됐어요. 인증 점포라 설명도 친절했습니다.", paid: 145000, item: "대게 2kg", color: "coral", rating: 5, receiptVerified: true },
  { id: "seed-review-3", name: "김서현", market: "부전시장", minutesAgo: 60, text: "전복 크기별 가격까지 확인하고 샀어요. 영수증 가격 그대로 공유합니다!", paid: 42000, item: "전복 10미", color: "teal", rating: 5, receiptVerified: true },
];

const shopBaseNames = ["바다정직수산", "민락 바다상회", "싱싱전복", "부산어부", "청정해산물", "바른수산", "해운대 어가", "남항수산", "푸른바다상회", "오늘의활어", "부산청정상회", "미소수산"];
const shopMarkets = ["자갈치시장", "민락회센터", "부전시장", "해운대전통시장"];
const shopSpecialties = ["광어 · 참돔", "대게 · 킹크랩", "전복 · 멍게", "활어 · 문어", "갑각류 · 패류", "활어 · 조개"];
const shopItems = ["광어", "참돔", "대게", "전복", "문어", "멍게"];
const shopBasePrices: Record<string, number> = { 광어: 28000, 참돔: 35000, 대게: 72000, 전복: 42000, 문어: 31000, 멍게: 15000 };
const certifiedShops = Array.from({ length: 86 }, (_, index) => {
  const primaryItem = shopItems[index % shopItems.length];
  return {
    name: `${shopBaseNames[index % shopBaseNames.length]} ${String(index + 1).padStart(2, "0")}`,
    market: shopMarkets[index % shopMarkets.length],
    specialty: shopSpecialties[index % shopSpecialties.length],
    primaryItem,
    price: Math.round(shopBasePrices[primaryItem] * (0.88 + (index % 9) * 0.025) / 100) * 100,
    score: (4.7 + (index % 3) * 0.1).toFixed(1),
    orders: 420 + ((index * 173) % 1780),
    certificationId: `SN-${String(index + 1).padStart(3, "0")}`,
  };
});
const cheapestByItem = certifiedShops.reduce<Record<string, { name: string; price: number }>>((result, shop) => {
  if (!result[shop.primaryItem] || shop.price < result[shop.primaryItem].price) result[shop.primaryItem] = { name: shop.name, price: shop.price };
  return result;
}, {});

const initialDiscussionPosts = [
  { id: 1, item: "광어", author: "부산초보", time: "5분 전", title: "광어 2kg이면 요즘 얼마가 적당할까요?", body: "주말에 자갈치시장에 가려고 합니다. 손질비 포함 가격을 알고 싶어요.", replies: 8, helpful: 12, lastReply: "지난주에는 손질 포함 5만 8천 원에 샀어요." },
  { id: 2, item: "대게", author: "여행하는민지", time: "18분 전", title: "대게 수율 확인하는 방법 공유해요", body: "다리 눌러보기와 배 쪽 색깔을 확인하니 고르기가 훨씬 쉬웠어요.", replies: 5, helpful: 21, lastReply: "좋은 팁 감사합니다! 이번 주에 확인해 볼게요." },
  { id: 3, item: "전복", author: "해산물러버", time: "42분 전", title: "전복 10미와 12미 차이가 큰가요?", body: "회로 먹을 예정인데 어떤 크기가 가성비 좋은지 경험을 듣고 싶습니다.", replies: 11, helpful: 9, lastReply: "회로는 10미가 식감도 좋고 만족스러웠어요." },
];

const seedReviewTexts: Partial<Record<Language, Record<string, string>>> = {
  en: {
    "seed-review-1": "Flounder, 2 kg for KRW 56,000. When I showed the price list, the store clearly explained the preparation fee first.",
    "seed-review-2": "I could compare the price and weight immediately, so I felt confident buying. The verified store also explained everything kindly.",
    "seed-review-3": "I checked prices by abalone size before buying. Sharing the exact price from my receipt!",
  },
  zh: {
    "seed-review-1": "比目鱼2公斤56,000韩元。出示行情表后，店家先清楚说明了加工费。",
    "seed-review-2": "可以立即比较价格和重量，购买时很放心。认证店铺的说明也很亲切。",
    "seed-review-3": "确认不同大小鲍鱼的价格后购买，分享小票上的实际价格！",
  },
  ja: {
    "seed-review-1": "ヒラメ2kgで56,000ウォン。相場表を見せると、調理代まで先に正確に説明してくれました。",
    "seed-review-2": "価格と重さをすぐ比較できて安心でした。認証店舗の説明も親切でした。",
    "seed-review-3": "アワビのサイズ別価格を確認して購入しました。レシートの価格をそのまま共有します！",
  },
};

const seedDiscussionTexts: Partial<Record<Language, Record<number, { author: string; time: string; title: string; body: string; lastReply: string }>>> = {
  en: {
    1: { author: "Busan beginner", time: "5 minutes ago", title: "What is a fair price for 2 kg of flounder?", body: "I’m visiting Jagalchi Market this weekend. I’d like to know the price including preparation.", lastReply: "Last week I paid KRW 58,000 including preparation." },
    2: { author: "Traveling Minji", time: "18 minutes ago", title: "How to check snow crab meat yield", body: "Pressing the legs and checking the color underneath made choosing much easier.", lastReply: "Great tip, thank you! I’ll check this week." },
    3: { author: "Seafood lover", time: "42 minutes ago", title: "Is there a big difference between 10- and 12-piece abalone?", body: "I plan to eat it raw and would love advice on which size offers better value.", lastReply: "For sashimi, the 10-piece size had a great texture and was satisfying." },
  },
  zh: {
    1: { author: "釜山新手", time: "5分钟前", title: "比目鱼2公斤现在多少钱比较合理？", body: "周末准备去札嘎其市场，想了解包含加工费的价格。", lastReply: "上周包含加工费是58,000韩元。" },
    2: { author: "旅行中的敏智", time: "18分钟前", title: "分享确认雪蟹出肉率的方法", body: "按一按蟹腿并查看腹部颜色，挑选起来容易多了。", lastReply: "谢谢实用建议！这周会试试看。" },
    3: { author: "海鲜爱好者", time: "42分钟前", title: "10只和12只规格的鲍鱼差别大吗？", body: "准备生吃，想听听哪种大小更划算。", lastReply: "做刺身的话，10只规格口感好，也很满意。" },
  },
  ja: {
    1: { author: "釜山初心者", time: "5分前", title: "ヒラメ2kgなら今はいくらが適正ですか？", body: "週末にチャガルチ市場へ行く予定です。調理代込みの価格を知りたいです。", lastReply: "先週は調理代込みで58,000ウォンでした。" },
    2: { author: "旅するミンジ", time: "18分前", title: "ズワイガニの身入りを確認する方法", body: "脚を押して腹側の色を確認すると、選びやすくなりました。", lastReply: "良い情報をありがとうございます！今週確認してみます。" },
    3: { author: "海鮮好き", time: "42分前", title: "アワビ10個と12個サイズは差が大きいですか？", body: "刺身で食べる予定です。どのサイズがコスパが良いか教えてください。", lastReply: "刺身なら10個サイズが食感も良く満足でした。" },
  },
};

const formatWon = (value: number) => new Intl.NumberFormat("ko-KR").format(value);
const parsePriceInput = (value: string) => Number(value.replace(/[^0-9]/g, ""));
const parseWeightInput = (value: string) => Number(value.replace(",", ".").replace(/[^0-9.]/g, ""));
const SHARE_URL = "https://giftedu119-cell.github.io/super-nova-busan-v2/";
const SITES_ORIGIN = "https://super-nova-busan.yeonhui-lim-5750.chatgpt.site";

function reviewsEndpoint() {
  return window.location.hostname.endsWith("github.io") ? `${SITES_ORIGIN}/api/reviews` : "/api/reviews";
}

function createLiveTransaction(): Transaction {
  const item = seafood[Math.floor(Math.random() * seafood.length)];
  const market = shopMarkets[Math.floor(Math.random() * shopMarkets.length)];
  const annualAverage = annualPriceHistory[item.name].reduce((sum, entry) => sum + entry.price, 0) / annualPriceHistory[item.name].length;
  const isTenPieceUnit = item.unit === "10미";
  const numericWeight = isTenPieceUnit ? 1 : Math.round((0.8 + Math.random() * 1.8) * 10) / 10;
  const fairVariation = 0.93 + Math.random() * 0.14;
  const paid = Math.round(annualAverage * numericWeight * fairVariation / 1000) * 1000;
  const now = new Date();

  return {
    id: `live-${now.getTime()}-${Math.random().toString(36).slice(2, 7)}`,
    time: now.toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit", hour12: false }),
    item: item.name,
    market,
    weight: isTenPieceUnit ? "10미" : `${numericWeight.toFixed(1)}kg`,
    total: `${formatWon(paid)}원`,
    fair: true,
  };
}

export default function Home() {
  const [language, setLanguage] = useState<Language>("ko");
  const [category, setCategory] = useState("전체");
  const [query, setQuery] = useState("");
  const [analysisItem, setAnalysisItem] = useState("광어");
  const [selectedSeafood, setSelectedSeafood] = useState("광어");
  const [weight, setWeight] = useState("1");
  const [paidPrice, setPaidPrice] = useState("32000");
  const [result, setResult] = useState<{ level: PriceLevel; percent: number; fair: number } | null>({
    level: "safe",
    percent: 6,
    fair: 30200,
  });
  const [showCertified, setShowCertified] = useState(false);
  const [showReviewComposer, setShowReviewComposer] = useState(false);
  const [showShareQr, setShowShareQr] = useState(false);
  const [shareCopied, setShareCopied] = useState(false);
  const [reviews, setReviews] = useState(initialReviews);
  const [reviewsLoading, setReviewsLoading] = useState(true);
  const [reviewSaving, setReviewSaving] = useState(false);
  const [reviewError, setReviewError] = useState("");
  const [liveTransactions, setLiveTransactions] = useState(initialTransactions);
  const [todayTradeCount, setTodayTradeCount] = useState(1248);
  const [tradesPaused, setTradesPaused] = useState(false);
  const [shopPage, setShopPage] = useState(0);
  const [shopSort, setShopSort] = useState<"rating" | "orders">("rating");
  const [discussionPosts, setDiscussionPosts] = useState(initialDiscussionPosts);
  const [discussionItem, setDiscussionItem] = useState("광어");
  const [discussionDraft, setDiscussionDraft] = useState("");
  const [activeReplyId, setActiveReplyId] = useState<number | null>(null);
  const [replyDraft, setReplyDraft] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [verificationSent, setVerificationSent] = useState(false);
  const [verificationCode, setVerificationCode] = useState("");
  const [phoneVerified, setPhoneVerified] = useState(false);
  const [phoneMessage, setPhoneMessage] = useState<PhoneMessageKey>("phoneIntro");

  useEffect(() => {
    const storedLanguage = window.localStorage.getItem("super-nova-language") as Language | null;
    const browserLanguage = navigator.language.toLowerCase();
    const detectedLanguage: Language = browserLanguage.startsWith("zh") ? "zh" : browserLanguage.startsWith("ja") ? "ja" : browserLanguage.startsWith("en") ? "en" : "ko";
    const nextLanguage = storedLanguage && languageOptions.some((option) => option.code === storedLanguage) ? storedLanguage : detectedLanguage;
    setLanguage(nextLanguage);
    document.documentElement.lang = nextLanguage === "zh" ? "zh-CN" : nextLanguage;
  }, []);

  useEffect(() => {
    let cancelled = false;
    fetch(reviewsEndpoint(), { cache: "no-store" })
      .then(async (response) => {
        if (!response.ok) throw new Error("reviews unavailable");
        return response.json() as Promise<{ reviews: Array<{ id: number; name: string; item: string; market: string; paid: number; rating: number; reviewText: string; receiptVerified: boolean; createdAt: string }> }>;
      })
      .then(({ reviews: savedReviews }) => {
        if (cancelled || savedReviews.length === 0) return;
        const sharedReviews: Review[] = savedReviews.map((review, index) => ({
          id: review.id,
          name: review.name,
          market: review.market,
          createdAt: review.createdAt,
          text: review.reviewText,
          paid: review.paid,
          item: review.item,
          color: ["teal", "coral", "navy"][index % 3],
          rating: review.rating,
          receiptVerified: review.receiptVerified,
        }));
        setReviews(sharedReviews);
      })
      .catch(() => undefined)
      .finally(() => { if (!cancelled) setReviewsLoading(false); });
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    if (tradesPaused) return;
    let timer: ReturnType<typeof window.setTimeout>;
    const scheduleNext = () => {
      const delay = 60_000 + Math.random() * 120_000;
      timer = window.setTimeout(() => {
        const nextTransaction = createLiveTransaction();
        setLiveTransactions((current) => [nextTransaction, ...current].slice(0, 12));
        setTodayTradeCount((current) => current + 1);
        scheduleNext();
      }, delay);
    };
    scheduleNext();
    return () => window.clearTimeout(timer);
  }, [tradesPaused]);

  const tr = (key: string) => messages[language][key] ?? messages.ko[key] ?? key;
  const seafoodName = (name: string) => seafoodLabels[language][name] ?? name;
  const marketName = (name: string) => marketLabels[language][name] ?? name;
  const unitName = (unit: string) => unit === "10미" ? ({ ko: "10미", en: "10 pcs", zh: "10只", ja: "10個" }[language]) : unit;
  const monthName = (month: string) => {
    const number = month.replace("월", "");
    return language === "ko" ? month : language === "en" ? `${number}M` : language === "zh" ? `${number}月` : `${number}月`;
  };
  const priceText = (value: number) => `${formatWon(value)}${tr("currency")}`;
  const localizedSeafoodText = (text: string) => Object.entries(seafoodLabels[language]).reduce((result, [ko, translated]) => result.replaceAll(ko, translated), text);
  const locale = ({ ko: "ko-KR", en: "en-US", zh: "zh-CN", ja: "ja-JP" } as const)[language];
  const reviewTime = (review: Review) => {
    let minutes = review.minutesAgo ?? 0;
    if (review.createdAt) {
      const createdAt = new Date(`${review.createdAt.replace(" ", "T")}Z`).getTime();
      minutes = Math.max(0, Math.round((Date.now() - createdAt) / 60_000));
    }
    const formatter = new Intl.RelativeTimeFormat(locale, { numeric: "auto" });
    return minutes >= 60 ? formatter.format(-Math.max(1, Math.round(minutes / 60)), "hour") : formatter.format(-minutes, "minute");
  };
  const reviewInitials = (name: string) => Array.from(name.trim()).slice(0, 2).join("").toUpperCase();

  const filteredSeafood = useMemo(() => {
    return seafood.filter((item) => {
      const normalizedQuery = query.trim().toLocaleLowerCase();
      const matchesQuery = item.name.includes(query.trim()) || (seafoodLabels[language][item.name] ?? item.name).toLocaleLowerCase().includes(normalizedQuery);
      const matchesCategory =
        category === "전체" ||
        (category === "활어" && ["광어", "참돔"].includes(item.name)) ||
        (category === "갑각류" && item.name === "대게") ||
        (category === "패류" && ["전복", "멍게"].includes(item.name)) ||
        (category === "기타" && item.name === "문어");
      return matchesQuery && matchesCategory;
    });
  }, [category, query, language]);

  const selectedHistory = annualPriceHistory[selectedSeafood];
  const selectedItem = seafood.find((item) => item.name === selectedSeafood) ?? seafood[0];
  const historyMin = Math.min(...selectedHistory.map((item) => item.price));
  const historyMax = Math.max(...selectedHistory.map((item) => item.price));
  const historyAverage = Math.round(selectedHistory.reduce((sum, item) => sum + item.price, 0) / selectedHistory.length / 100) * 100;
  const shopsPerPage = 12;
  const shopPageCount = Math.ceil(certifiedShops.length / shopsPerPage);
  const sortedShops = useMemo(() => [...certifiedShops].sort((a, b) => shopSort === "rating" ? Number(b.score) - Number(a.score) || b.orders - a.orders : b.orders - a.orders || Number(b.score) - Number(a.score)), [shopSort]);
  const visibleShops = sortedShops.slice(shopPage * shopsPerPage, (shopPage + 1) * shopsPerPage);

  function analyzePrice(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const selected = seafood.find((item) => item.name === analysisItem) ?? seafood[0];
    const numericWeight = Math.max(parseWeightInput(weight) || 1, 0.1);
    const paid = Math.max(parsePriceInput(paidPrice) || 0, 0);
    const annualAverage = annualPriceHistory[selected.name].reduce((sum, entry) => sum + entry.price, 0) / annualPriceHistory[selected.name].length;
    const fair = Math.round(annualAverage * numericWeight / 100) * 100;
    const rawPercent = ((paid - fair) / fair) * 100;
    const percent = Math.round(rawPercent);

    if (paid > fair * 1.2) {
      setResult({ level: "danger", percent, fair });
    } else if (rawPercent <= 8) {
      setResult({ level: "safe", percent, fair });
    } else {
      setResult({ level: "caution", percent, fair });
    }
  }

  async function submitReview(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setReviewSaving(true);
    setReviewError("");
    const form = new FormData(event.currentTarget);
    const name = String(form.get("name") ?? "").trim();
    const item = String(form.get("item"));
    const market = String(form.get("market"));
    const paid = parsePriceInput(String(form.get("paid") ?? ""));
    const rating = Number(form.get("rating"));
    const text = String(form.get("review"));
    try {
      const response = await fetch(reviewsEndpoint(), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, item, market, paid, rating, reviewText: text }),
      });
      const payload = await response.json() as { review?: { id: number; createdAt: string; receiptVerified: boolean }; error?: string };
      if (!response.ok || !payload.review) throw new Error(payload.error || tr("reviewSaveError"));
      setReviews((current) => [{
        id: payload.review!.id,
        name,
        market,
        createdAt: payload.review!.createdAt,
        text,
        paid,
        item,
        color: "teal",
        rating,
        receiptVerified: payload.review!.receiptVerified,
      }, ...current]);
      setShowReviewComposer(false);
      event.currentTarget.reset();
    } catch (error) {
      setReviewError(error instanceof Error ? error.message : tr("reviewSaveError"));
    } finally {
      setReviewSaving(false);
    }
  }

  function submitDiscussion(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!phoneVerified || !discussionDraft.trim()) return;
    setDiscussionPosts((current) => [{
      id: Date.now(),
      item: discussionItem,
      author: "나",
      time: "방금 전",
      title: `${discussionItem}에 대해 궁금해요`,
      body: discussionDraft.trim(),
      replies: 0,
      helpful: 0,
      lastReply: "첫 답변을 기다리고 있어요.",
    }, ...current]);
    setDiscussionDraft("");
  }

  function submitReply(event: FormEvent<HTMLFormElement>, postId: number) {
    event.preventDefault();
    if (!phoneVerified || !replyDraft.trim()) return;
    setDiscussionPosts((current) => current.map((post) => post.id === postId ? { ...post, replies: post.replies + 1, lastReply: replyDraft.trim() } : post));
    setReplyDraft("");
    setActiveReplyId(null);
  }

  function sendVerificationCode() {
    const digits = phoneNumber.replace(/\D/g, "");
    if (digits.length < 10 || digits.length > 11) {
      setPhoneMessage("invalidPhone");
      return;
    }
    setVerificationSent(true);
    setPhoneMessage("codeSent");
  }

  function verifyPhoneNumber() {
    if (verificationCode === "123456") {
      setPhoneVerified(true);
      setPhoneMessage("verified");
    } else {
      setPhoneMessage("invalidCode");
    }
  }

  function openReply(postId: number) {
    if (!phoneVerified) {
      setPhoneMessage("verifyFirst");
      document.getElementById("phone-verification")?.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }
    setActiveReplyId(activeReplyId === postId ? null : postId);
    setReplyDraft("");
  }

  async function copyShareLink() {
    await navigator.clipboard.writeText(SHARE_URL);
    setShareCopied(true);
    window.setTimeout(() => setShareCopied(false), 1800);
  }

  return (
    <main>
      <header className="topbar">
        <a className="brand" href="#top" aria-label="SUPER 노바 홈">
          <span className="brand-mark">S</span>
          <span className="brand-word">SUPER <b>노바</b></span>
        </a>
        <nav className="desktop-nav" aria-label={tr("navPrices")}>
          <a className="active" href="#prices">{tr("navPrices")}</a>
          <a href="#analysis">{tr("navAnalysis")}</a>
          <a href="#trades">{tr("navTrades")}</a>
          <a href="#community">{tr("navReviews")}</a>
        </nav>
        <div className="header-actions">
          <button className="ghost-button" type="button" aria-label={tr("region")}>{tr("region")} <span>⌄</span></button>
          <button className="share-button" type="button" onClick={() => setShowShareQr(true)} aria-label={tr("shareQrTitle")}><span aria-hidden="true">▦</span><b>{tr("share")}</b></button>
          <label className="language-select">
            <img className="language-icon" src="globe.svg" alt="" aria-hidden="true" />
            <span className="sr-only">{tr("language")}</span>
            <select
              value={language}
              onChange={(event) => {
                const nextLanguage = event.target.value as Language;
                setLanguage(nextLanguage);
                setQuery("");
                window.localStorage.setItem("super-nova-language", nextLanguage);
                document.documentElement.lang = nextLanguage === "zh" ? "zh-CN" : nextLanguage;
              }}
              aria-label={tr("language")}
            >
              {languageOptions.map((option) => <option key={option.code} value={option.code}>{option.label}</option>)}
            </select>
          </label>
          <button className="profile" type="button" aria-label="내 정보">MY</button>
        </div>
      </header>

      <section className="hero" id="top">
        <div className="hero-copy">
          <div className="eyebrow"><span className="live-dot" /> {tr("heroLive")}</div>
          <h1>{tr("heroLine1")}<br /><em>{tr("heroLine2")}</em></h1>
          <p>{tr("heroDescription")}</p>
          <div className="hero-stats" aria-label="서비스 현황">
            <div><strong aria-live="polite">{formatWon(todayTradeCount)}</strong><span>{tr("todayTrades")}</span></div>
            <div><strong>86</strong><span>{tr("certifiedShops")}</span></div>
            <div><strong>4.9</strong><span>{tr("satisfaction")}</span></div>
          </div>
        </div>

        <div className="hero-panel" aria-label="오늘의 시장 요약">
          <div className="panel-head">
            <div><span>{tr("marketIndex")}</span><strong>{tr("good")}</strong></div>
            <div className="signal"><i /><i /><i /><i /></div>
          </div>
          <div className="market-score">
            <div className="score-ring"><strong>92</strong><span>/ 100</span></div>
            <div><b>{tr("fairRange")}</b><p>{tr("cheaperYesterday")}</p></div>
          </div>
          <div className="panel-bars">
            <div><span>{tr("stability")}</span><i><b style={{ width: "92%" }} /></i><strong>92%</strong></div>
            <div><span>{tr("freshness")}</span><i><b style={{ width: "88%" }} /></i><strong>88%</strong></div>
            <div><span>{tr("transparency")}</span><i><b style={{ width: "96%" }} /></i><strong>96%</strong></div>
          </div>
          <p className="data-note"><span>✓</span> {tr("dataBasis")}</p>
        </div>
        <div className="hero-orbit orbit-one" />
        <div className="hero-orbit orbit-two" />
      </section>

      <section className="content-section prices-section" id="prices">
        <div className="section-heading">
          <div>
            <span className="section-kicker">{tr("pricesKicker")}</span>
            <h2>{tr("pricesTitle")}</h2>
            <p><span className="live-dot" /> {tr("updateText")}</p>
          </div>
          <label className="search-box">
            <span>⌕</span>
            <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={tr("searchPlaceholder")} aria-label={tr("searchPlaceholder")} />
          </label>
        </div>

        <div className="category-row" aria-label="수산물 종류 필터">
          {["전체", "활어", "갑각류", "패류", "기타"].map((item) => (
            <button key={item} type="button" onClick={() => setCategory(item)} className={category === item ? "selected" : ""}>{categoryLabels[language][item]}</button>
          ))}
        </div>

        <div className="price-grid">
          {filteredSeafood.map((item) => (
            <button className={`price-card ${selectedSeafood === item.name ? "selected-card" : ""}`} type="button" onClick={() => setSelectedSeafood(item.name)} aria-pressed={selectedSeafood === item.name} key={item.name}>
              <div className={`seafood-icon ${item.tone} ${item.photo ? "photo" : ""}`} aria-hidden="true">
                {item.photo ? <img className="seafood-photo" src={item.photo} alt="" /> : item.icon}
              </div>
              <div className="price-card-main">
                <div className="item-title"><h3>{seafoodName(item.name)}</h3><span>{freshnessLabels[language][item.freshness]}</span></div>
                <div className="main-price"><strong>{formatWon(item.price)}</strong><span>{tr("currency")} / {unitName(item.unit)}</span></div>
                <div className="range">{tr("tradeRange")} {item.range}{tr("currency")}</div>
              </div>
              <div className={`change ${item.change > 0 ? "up" : "down"}`}>{item.change > 0 ? "▲" : "▼"} {Math.abs(item.change)}%</div>
              {selectedSeafood === item.name && <span className="trend-hint">{tr("viewAnnualTrend")}</span>}
            </button>
          ))}
          {filteredSeafood.length === 0 && <p className="empty-state">{tr("noResults")}</p>}
        </div>
        <section className="price-history" aria-labelledby="history-title">
          <div className="history-heading">
            <div>
              <span className="history-overline">{tr("priceHistory")}</span>
              <h3 id="history-title">{seafoodName(selectedSeafood)} {tr("priceChange")}</h3>
              <p>{tr("historyHint")}</p>
            </div>
            <div className="history-current"><span>{tr("currentAverage")}</span><strong>{priceText(selectedItem.price)}</strong><small>/ {unitName(selectedItem.unit)}</small></div>
          </div>
          <div className="history-chart" role="img" aria-label={`${selectedSeafood}의 지난 1년 월별 가격 변동 그래프`}>
            <div className="chart-grid"><i /><i /><i /><i /></div>
            <div className="chart-bars">
              {selectedHistory.map((entry, index) => {
                const height = 30 + ((entry.price - historyMin) / Math.max(historyMax - historyMin, 1)) * 70;
                return <div className="chart-column" key={entry.month}><span className="bar-value">{formatWon(entry.price)}</span><i className={index === selectedHistory.length - 1 ? "latest-bar" : ""} style={{ height: `${height}%` }} /><b>{monthName(entry.month)}</b></div>;
              })}
            </div>
          </div>
          <div className="history-summary"><span className="history-dot" /> <b>{tr("min")} {priceText(historyMin)}</b><span>·</span><b className="average-value">{tr("average")} {priceText(historyAverage)}</b><span>·</span><b>{tr("max")} {priceText(historyMax)}</b><span>·</span><span>{tr("monthlyAverage")}</span></div>
        </section>
        <button className="text-link" type="button" onClick={() => { setCategory("전체"); setQuery(""); }}>{tr("viewAll")} <span>→</span></button>
      </section>

      <section className="analysis-section" id="analysis">
        <div className="analysis-intro">
          <span className="section-kicker light">{tr("analysisKicker")}</span>
          <h2>{tr("analysisTitle")}</h2>
          <p>{tr("analysisDescription")}</p>
          <div className="ai-points">
            <div><span>01</span><p><b>{formatWon(todayTradeCount)}</b>{tr("realtimeData")}</p></div>
            <div><span>02</span><p><b>97.3%</b>{tr("accuracy")}</p></div>
            <div><span>03</span><p><b>{tr("threeSeconds")}</b>{tr("fastResult")}</p></div>
          </div>
        </div>

        <form className="analyzer" onSubmit={analyzePrice}>
          <div className="analyzer-title"><span>AI</span><div><h3>{tr("analyzerTitle")}</h3><p>{tr("analyzerHint")}</p></div></div>
          <div className="form-row">
            <label><span>{tr("seafood")}</span><select value={analysisItem} onChange={(event) => setAnalysisItem(event.target.value)}>{seafood.map((item) => <option key={item.name} value={item.name}>{seafoodName(item.name)}</option>)}</select></label>
            <label><span>{tr("weight")}</span><div className="input-unit"><input type="text" inputMode="decimal" value={weight} onChange={(event) => setWeight(event.target.value)} aria-label={tr("weight")} /><b>kg</b></div></label>
          </div>
          <label className="price-input-label"><span>{tr("offeredPrice")}</span><div className="input-unit large"><input type="text" inputMode="numeric" value={paidPrice} onChange={(event) => setPaidPrice(event.target.value)} aria-label={tr("offeredPrice")} /><b>{tr("currency")}</b></div></label>
          <button className="analyze-button" type="submit">{tr("analyze")} <span>✦</span></button>

          {result && (
            <div className={`result-box ${result.level}`} aria-live="polite">
              <div className="result-top">
                <div className="result-icon">{result.level === "safe" ? "✓" : result.level === "danger" ? "!" : "△"}</div>
                <div><span>{tr("aiResult")}</span><strong>{tr(result.level)}</strong></div>
                <b>{result.percent > 0 ? "+" : ""}{result.percent}%</b>
              </div>
              <p>{tr(`${result.level}Message`)}</p>
              <div className="fair-price"><span>{tr("annualReference")}</span><strong>{priceText(result.fair)}</strong></div>
            </div>
          )}
        </form>
      </section>

      <section className="content-section trade-section" id="trades">
        <div className="section-heading compact">
          <div><span className="section-kicker">{tr("tradesKicker")}</span><h2>{tr("recentTitle")}</h2><p>{tr("recentDescription")}</p></div>
          <a href="#community">{tr("shareTrade")} <span>＋</span></a>
        </div>
        <div className="trade-table" role="table" aria-label={tr("navTrades")}>
          <div className="trade-row trade-head" role="row"><span>{tr("tradeTime")}</span><span>{tr("item")}</span><span>{tr("market")}</span><span>{tr("quantity")}</span><span>{tr("paid")}</span><span>{tr("judgment")}</span></div>
          {liveTransactions.map((trade) => (
            <div className="trade-row" role="row" key={trade.id}>
              <span data-label={tr("tradeTime")}><i className="live-dot" /> {trade.time}</span>
              <strong data-label={tr("item")}>{seafoodName(trade.item)}</strong>
              <span data-label={tr("market")}>{marketName(trade.market)}</span>
              <span data-label={tr("quantity")}>{unitName(trade.weight)}</span>
              <strong data-label={tr("paid")}>{trade.total.replace("원", tr("currency"))}</strong>
              <span data-label={tr("judgment")} className={trade.fair ? "fair-badge" : "check-badge"}>{trade.fair ? `✓ ${tr("fair")}` : `△ ${tr("check")}`}</span>
            </div>
          ))}
        </div>
        <div className="trade-controls">
          <span aria-live="polite"><i className={`live-dot ${tradesPaused ? "paused-dot" : ""}`} /> {tr(tradesPaused ? "tradeFeedPaused" : "tradeFeedLive")}</span>
          <button type="button" disabled={tradesPaused} onClick={() => setTradesPaused(true)}>{tr("pauseTrades")}</button>
          <button type="button" disabled={!tradesPaused} onClick={() => setTradesPaused(false)}>{tr("resumeTrades")}</button>
        </div>
        <div className="verification-banner"><span className="shield">✓</span><div><strong>{tr("verifiedBannerTitle")}</strong><p>{tr("verifiedBannerDescription")}</p></div><button type="button" onClick={() => { setShopPage(0); setShowCertified(true); }}>{tr("viewStores")} <span>→</span></button></div>
      </section>

      <section className="community-section" id="community">
        <div className="content-section">
          <div className="section-heading compact">
            <div><span className="section-kicker">{tr("reviewsKicker")}</span><h2>{tr("reviewsTitle")}</h2><p>{tr("reviewsDescription")}</p></div>
            <button className="outline-button" type="button" onClick={() => { setReviewError(""); setShowReviewComposer(true); }}>{tr("writeReview")} <span>✎</span></button>
          </div>
          {reviewsLoading && <p className="reviews-loading">{tr("reviewsLoading")}</p>}
          <div className="review-grid">
            {reviews.map((review) => {
              const localizedReviewText = typeof review.id === "string" ? seedReviewTexts[language]?.[review.id] ?? review.text : review.text;
              return <article className="review-card" key={review.id}>
                <div className="reviewer"><span className={`avatar ${review.color}`}>{reviewInitials(review.name)}</span><div><strong>{review.name}</strong><p>{marketName(review.market)} · {reviewTime(review)}</p></div><span className={review.receiptVerified ? "receipt" : "receipt pending"}>{tr(review.receiptVerified ? "receiptVerified" : "receiptPending")}</span></div>
                <div className="stars" aria-label={`${tr("rating")} ${review.rating}`}>{"★".repeat(review.rating)}{"☆".repeat(5 - review.rating)}</div>
                <p className="review-text">“{localizedReviewText}”</p>
                <div className="review-price"><span>{localizedSeafoodText(review.item.replace("10미", unitName("10미")))}</span><strong>{priceText(review.paid)}</strong></div>
              </article>;
            })}
          </div>
          <section className="discussion-area" aria-labelledby="discussion-title">
            <div className="discussion-heading">
              <div><span className="section-kicker">{tr("communityKicker")}</span><h2 id="discussion-title">{tr("communityTitle")}</h2><p>{tr("communityDescription")}</p></div>
              <div className="talk-status"><span className="talk-live"><i className="live-dot" /> {tr("liveChat")}</span><span className={phoneVerified ? "verified-phone" : "phone-required"}>{phoneVerified ? `✓ ${tr("phoneDone")}` : tr("phoneRequired")}</span></div>
            </div>
            <div className="discussion-layout">
              {phoneVerified ? <form className="new-discussion" onSubmit={submitDiscussion}>
                <div className="discussion-form-head"><span>＋</span><div><strong>{tr("newTopic")}</strong><p>{tr("newTopicHint")}</p></div></div>
                <label>{tr("chooseSeafood")}<select value={discussionItem} onChange={(event) => setDiscussionItem(event.target.value)}>{seafood.map((item) => <option key={item.name} value={item.name}>{seafoodName(item.name)}</option>)}</select></label>
                <label>{tr("content")}<textarea value={discussionDraft} onChange={(event) => setDiscussionDraft(event.target.value)} rows={5} placeholder={tr("discussionPlaceholder")} required /></label>
                <button type="submit">{tr("postTopic")} <span>→</span></button>
              </form> : <section className="phone-verification" id="phone-verification" aria-labelledby="phone-title">
                <div className="phone-lock">☎</div>
                <span className="phone-overline">{tr("phoneKicker")}</span>
                <h3 id="phone-title">{tr("phoneTitle")}</h3>
                <p>{tr("phoneDescription")}</p>
                <label>{tr("mobileNumber")}<div className="phone-input-row"><input value={phoneNumber} onChange={(event) => setPhoneNumber(event.target.value)} type="tel" inputMode="numeric" placeholder="010-1234-5678" /><button type="button" onClick={sendVerificationCode}>{tr("getCode")}</button></div></label>
                {verificationSent && <label>{tr("verificationCode")}<div className="phone-input-row"><input value={verificationCode} onChange={(event) => setVerificationCode(event.target.value)} inputMode="numeric" maxLength={6} placeholder={tr("codePlaceholder")} /><button type="button" onClick={verifyPhoneNumber}>{tr("verify")}</button></div></label>}
                <div className="phone-message" aria-live="polite">{tr(phoneMessage)}</div>
                <small>{tr("demoNotice")}</small>
              </section>}
              <div className="discussion-list">
                {discussionPosts.map((post) => {
                  const localizedPost = seedDiscussionTexts[language]?.[post.id];
                  return <article className="discussion-post" key={post.id}>
                    <div className="post-meta"><span>{seafoodName(post.item)}</span><b>{localizedPost?.author ?? post.author}</b><time>{localizedPost?.time ?? post.time}</time></div>
                    <h3>{localizedPost?.title ?? post.title}</h3>
                    <p>{localizedPost?.body ?? post.body}</p>
                    <div className="last-reply"><span>↳</span><p>{localizedPost?.lastReply ?? post.lastReply}</p></div>
                    <div className="post-actions"><span>{tr("helpful")} {post.helpful}</span><button type="button" onClick={() => openReply(post.id)}>{phoneVerified ? tr("join") : tr("joinAfterVerify")} {post.replies}</button></div>
                    {activeReplyId === post.id && <form className="reply-form" onSubmit={(event) => submitReply(event, post.id)}><input value={replyDraft} onChange={(event) => setReplyDraft(event.target.value)} placeholder={tr("replyPlaceholder")} autoFocus required /><button type="submit">{tr("submit")}</button></form>}
                  </article>;
                })}
              </div>
            </div>
          </section>
        </div>
      </section>

      <section className="cta-section">
        <div><span>{tr("ctaOverline")}</span><h2>{tr("ctaTitle")}</h2></div>
        <a href="#prices">{tr("ctaButton")} <span>→</span></a>
      </section>

      <footer>
        <a className="brand footer-brand" href="#top"><span className="brand-mark">S</span><span className="brand-word">SUPER <b>노바</b></span></a>
        <p>{tr("footerDescription")}</p>
        <div className="footer-links"><a href="#prices">{tr("serviceIntro")}</a><a href="#analysis">{tr("navAnalysis")}</a><a href="#community">{tr("community")}</a><a href="#top">{tr("terms")}</a></div>
        <small>© 2026 SUPER NOVA. All rights reserved.</small>
      </footer>

      <nav className="mobile-nav" aria-label="모바일 메뉴">
        <a className="active" href="#prices"><span>⌁</span>{tr("mobilePrices")}</a>
        <a href="#analysis"><span>✦</span>{tr("mobileAnalysis")}</a>
        <a href="#trades"><span>▤</span>{tr("mobileTrades")}</a>
        <a href="#community"><span>◌</span>{tr("mobileReviews")}</a>
      </nav>

      {showShareQr && (
        <div className="modal-backdrop" role="presentation">
          <section className="modal-card share-modal" role="dialog" aria-modal="true" aria-labelledby="share-qr-title">
            <button className="modal-close" type="button" onClick={() => setShowShareQr(false)} aria-label={tr("closeShare")}>×</button>
            <span className="modal-kicker">{tr("shareKicker")}</span>
            <h2 id="share-qr-title">{tr("shareQrTitle")}</h2>
            <p>{tr("shareQrDescription")}</p>
            <div className="qr-frame"><img src="share-qr.png" alt={tr("scanQr")} width="720" height="720" /></div>
            <p className="share-url">{SHARE_URL}</p>
            <div className="share-actions">
              <button type="button" onClick={copyShareLink}>{shareCopied ? tr("linkCopied") : tr("copyLink")}</button>
              <a href="share-qr.png" download="super-nova-busan-qr.png">{tr("downloadQr")}</a>
            </div>
            <a className="share-open" href={SHARE_URL} target="_blank" rel="noreferrer">{tr("openSite")} <span>↗</span></a>
          </section>
        </div>
      )}

      {showCertified && (
        <div className="modal-backdrop" role="presentation">
          <section className="modal-card certified-modal" role="dialog" aria-modal="true" aria-labelledby="certified-title">
            <button className="modal-close" type="button" onClick={() => setShowCertified(false)} aria-label="인증 점포 목록 닫기">×</button>
            <span className="modal-kicker">{tr("verifiedKicker")}</span>
            <h2 id="certified-title">{tr("certifiedModalTitle")}</h2>
            <p>{tr("certifiedModalDescription")}</p>
            <div className="price-comparison-strip">
              {shopItems.map((item) => <div key={item}><span>{seafoodName(item)} {tr("lowest")}</span><strong>{priceText(cheapestByItem[item].price)}</strong><small>{cheapestByItem[item].name}</small></div>)}
            </div>
            <div className="shop-toolbar"><div className="shop-sort" aria-label={tr("certifiedShops")}><button type="button" className={shopSort === "rating" ? "active" : ""} onClick={() => { setShopSort("rating"); setShopPage(0); }}>{tr("ratingSort")}</button><button type="button" className={shopSort === "orders" ? "active" : ""} onClick={() => { setShopSort("orders"); setShopPage(0); }}>{tr("ordersSort")}</button></div><div className="shop-list-status"><strong>{tr("totalStores")}</strong><span>{shopPage * shopsPerPage + 1}–{Math.min((shopPage + 1) * shopsPerPage, certifiedShops.length)}{tr("storeCountSuffix")}</span></div></div>
            <div className="certified-list">
              {visibleShops.map((shop) => { const isCheapest = cheapestByItem[shop.primaryItem].price === shop.price; return <article className={`certified-shop ${isCheapest ? "cheapest-shop" : ""}`} key={shop.certificationId}><span className="shop-seal">✓</span><div className="shop-info"><strong>{shop.name}</strong><p>{marketName(shop.market)} · {shop.certificationId}</p><div className="shop-price"><span>{seafoodName(shop.primaryItem)} {priceText(shop.price)}</span>{isCheapest && <em>{tr("itemLowest")}</em>}</div></div><b>★ {shop.score}<small>{tr("orders")} {formatWon(shop.orders)}{tr("orderCountSuffix")}</small></b></article>; })}
            </div>
            <div className="shop-pagination"><button type="button" disabled={shopPage === 0} onClick={() => setShopPage((page) => page - 1)}>← {tr("previous")}</button><span><b>{shopPage + 1}</b> / {shopPageCount}</span><button type="button" disabled={shopPage === shopPageCount - 1} onClick={() => setShopPage((page) => page + 1)}>{tr("next")} →</button></div>
          </section>
        </div>
      )}

      {showReviewComposer && (
        <div className="modal-backdrop" role="presentation">
          <section className="modal-card review-modal" role="dialog" aria-modal="true" aria-labelledby="review-title">
            <button className="modal-close" type="button" onClick={() => setShowReviewComposer(false)} aria-label="후기 작성 창 닫기">×</button>
            <span className="modal-kicker">{tr("reviewKicker")}</span>
            <h2 id="review-title">{tr("reviewModalTitle")}</h2>
            <p>{tr("reviewModalDescription")}</p>
            <form className="review-form" onSubmit={submitReview}>
              <div className="review-form-row"><label>{tr("nickname")}<input name="name" type="text" minLength={2} maxLength={30} placeholder={tr("nicknamePlaceholder")} required /></label><label>{tr("rating")}<select name="rating" defaultValue="5" required>{[0, 1, 2, 3, 4, 5].map((score) => <option value={score} key={score}>{score}{tr("ratingSuffix")}</option>)}</select></label></div>
              <div className="review-form-row"><label>{tr("purchaseItem")}<select name="item" required>{seafood.map((item) => <option key={item.name} value={`${item.name} ${item.unit}`}>{seafoodName(item.name)} · {unitName(item.unit)}</option>)}</select></label><label>{tr("purchaseMarket")}<select name="market" required><option value="자갈치시장">{marketName("자갈치시장")}</option><option value="민락회센터">{marketName("민락회센터")}</option><option value="부전시장">{marketName("부전시장")}</option></select></label></div>
              <label>{tr("actualPaid")}<input name="paid" type="text" inputMode="numeric" placeholder="56,000" required /><span className="field-unit">{tr("currency")}</span></label>
              <label>{tr("review")}<textarea name="review" rows={4} minLength={5} maxLength={500} placeholder={tr("reviewPlaceholder")} required /></label>
              <label className="receipt-upload"><span className="upload-icon">▣</span><span><b>{tr("attachReceipt")}</b><small>{tr("fileRequired")}</small></span><input name="receipt" type="file" accept="image/png,image/jpeg" required /></label>
              {reviewError && <p className="form-error" role="alert">{reviewError}</p>}
              <button className="modal-confirm" type="submit" disabled={reviewSaving}>{reviewSaving ? tr("savingReview") : tr("submitReview")}</button>
            </form>
          </section>
        </div>
      )}
    </main>
  );
}

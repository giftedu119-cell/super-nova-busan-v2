import { sql } from "drizzle-orm";
import { index, integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const reviews = sqliteTable("reviews", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  item: text("item").notNull(),
  market: text("market").notNull(),
  paid: integer("paid").notNull(),
  rating: integer("rating").notNull().default(5),
  reviewText: text("review_text").notNull(),
  receiptVerified: integer("receipt_verified", { mode: "boolean" }).notNull().default(false),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("idx_reviews_created_at").on(table.createdAt),
]);
